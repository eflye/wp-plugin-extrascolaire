<?php
if (!defined('ABSPATH')) exit;

/**
 * Demandes d'inscription des familles non encore connues de la mairie.
 *
 * Parcours en deux temps, volontairement :
 *
 *   1. Le parent remplit le formulaire public. La demande est créée avec
 *      le statut "unverified" et N'APPARAÎT PAS dans le backoffice.
 *      Un e-mail de vérification est envoyé.
 *   2. Le parent clique sur le lien reçu : la demande passe en "pending"
 *      et rejoint la file de modération de la mairie.
 *
 * Sans cette étape, un robot pourrait remplir la file de demandes avec
 * des adresses inventées, et la mairie passerait son temps à trier du
 * bruit. Ici, seules des adresses réelles atteignent le backoffice.
 */
class Psc_Requests {

    const MAX_CHILDREN = 5;

    public static function init() {
        add_action('admin_post_nopriv_psc_submit_request', array(__CLASS__, 'handle_submit'));
        add_action('admin_post_psc_submit_request', array(__CLASS__, 'handle_submit'));
        add_action('init', array(__CLASS__, 'maybe_verify'), 6);

        add_action('admin_post_psc_approve_request', array(__CLASS__, 'handle_approve'));
        add_action('admin_post_psc_reject_request', array(__CLASS__, 'handle_reject'));
        add_action('admin_post_psc_delete_request', array(__CLASS__, 'handle_delete'));

        // Purge automatique des demandes anciennes (RGPD : on ne conserve
        // pas indéfiniment les données de familles jamais inscrites).
        add_action('psc_cleanup_requests', array(__CLASS__, 'cleanup'));
    }

    public static function schedule_cleanup() {
        if (!wp_next_scheduled('psc_cleanup_requests')) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'psc_cleanup_requests');
        }
    }

    public static function unschedule_cleanup() {
        $ts = wp_next_scheduled('psc_cleanup_requests');
        if ($ts) wp_unschedule_event($ts, 'psc_cleanup_requests');
    }

    /**
     * Zone d'attente pour les justificatifs d'assurance scolaire uploadés
     * avec le wizard public : aucun child_id n'existe encore à ce stade
     * (la demande doit d'abord être vérifiée par e-mail PUIS approuvée par
     * la mairie). Les fichiers y restent jusqu'à ce que handle_approve()
     * les rattache à un vrai enfant (Psc_Frontend::promote_pending_assurance())
     * ou que la demande soit purgée sans jamais avoir été approuvée.
     */
    protected static function pending_assurance_dir($request_id) {
        $upload_dir = wp_upload_dir();
        return trailingslashit($upload_dir['basedir']) . 'periscolaire/assurances/pending/' . (int) $request_id;
    }

    protected static function delete_pending_assurance_files($request_id) {
        $dir = self::pending_assurance_dir($request_id);
        if (!is_dir($dir)) return;
        foreach (glob(trailingslashit($dir) . '*') as $file) {
            @unlink($file); // phpcs:ignore WordPress.PHP.NoSilencedErrors
        }
        @rmdir($dir); // phpcs:ignore WordPress.PHP.NoSilencedErrors
    }

    /**
     * Supprime les demandes non vérifiées de plus de 7 jours et les
     * demandes traitées de plus de 90 jours — et, avec elles, tout
     * justificatif d'assurance resté en zone d'attente (jamais promu si la
     * demande n'a jamais été approuvée).
     */
    public static function cleanup() {
        global $wpdb;
        $t = psc_table('requests');

        $unverified_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM $t WHERE status = 'unverified' AND created_at < %s",
            gmdate('Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS)
        ));
        $stale_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM $t WHERE status IN ('approved','rejected') AND decided_at < %s",
            gmdate('Y-m-d H:i:s', time() - 90 * DAY_IN_SECONDS)
        ));
        foreach (array_merge($unverified_ids, $stale_ids) as $id) {
            self::delete_pending_assurance_files($id);
        }

        $wpdb->query($wpdb->prepare(
            "DELETE FROM $t WHERE status = 'unverified' AND created_at < %s",
            gmdate('Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS)
        ));
        $wpdb->query($wpdb->prepare(
            "DELETE FROM $t WHERE status IN ('approved','rejected') AND decided_at < %s",
            gmdate('Y-m-d H:i:s', time() - 90 * DAY_IN_SECONDS)
        ));
    }

    /* ---------------- Lecture ---------------- */

    public static function get($id) {
        global $wpdb;
        $id = absint($id);
        if (!$id) return null;
        $t = psc_table('requests');
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id = %d", $id));
    }

    /**
     * Demandes visibles par la mairie : uniquement celles dont l'adresse
     * e-mail a été vérifiée.
     */
    public static function by_status($status = 'pending') {
        global $wpdb;
        $t = psc_table('requests');
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $t WHERE status = %s AND verified = 1 ORDER BY created_at ASC",
            $status
        ));
    }

    public static function pending_count() {
        global $wpdb;
        $t = psc_table('requests');
        return (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM $t WHERE status = 'pending' AND verified = 1"
        );
    }

    /**
     * Décode la liste d'enfants stockée en JSON.
     * Les données proviennent d'une saisie publique : on revalide la
     * structure au lieu de faire confiance au contenu stocké.
     */
    public static function children_of($request) {
        if (empty($request->children_json)) return array();
        $data = json_decode($request->children_json, true);
        if (!is_array($data)) return array();

        $out = array();
        foreach ($data as $c) {
            if (!is_array($c)) continue;
            $nom       = isset($c['nom']) ? sanitize_text_field($c['nom']) : '';
            $prenom    = isset($c['prenom']) ? sanitize_text_field($c['prenom']) : '';
            $classe    = isset($c['classe']) ? sanitize_text_field($c['classe']) : '';
            $naissance = isset($c['date_naissance']) ? psc_valid_date($c['date_naissance']) : false;
            if ($nom === '' || $prenom === '') continue;
            $out[] = array(
                'nom'                          => $nom,
                'prenom'                       => $prenom,
                'classe'                       => $classe,
                'date_naissance'               => $naissance ?: '',
                'sans_porc'                    => !empty($c['sans_porc']) ? 1 : 0,
                'vegan'                        => !empty($c['vegan']) ? 1 : 0,
                'assurance_rel_path'           => isset($c['assurance_rel_path']) ? sanitize_text_field($c['assurance_rel_path']) : '',
                'assurance_original_filename'  => isset($c['assurance_original_filename']) ? sanitize_text_field($c['assurance_original_filename']) : '',
                'personnes_autorisees'         => self::pickup_persons_of($c),
            );
            if (count($out) >= self::MAX_CHILDREN) break;
        }
        return $out;
    }

    /**
     * Décode et revalide le sous-tableau personnes_autorisees d'un enfant
     * (issu de children_json, donc d'une saisie publique) — même
     * principe que children_of() : jamais fait confiance au contenu
     * stocké. Une ligne sans nom/prénom/téléphone est silencieusement
     * ignorée (la liste est facultative), contrairement à un enfant
     * incomplet qui fait échouer toute la soumission (cf. handle_submit()).
     */
    protected static function pickup_persons_of($child) {
        if (empty($child['personnes_autorisees']) || !is_array($child['personnes_autorisees'])) {
            return array();
        }
        $out = array();
        foreach ($child['personnes_autorisees'] as $p) {
            if (!is_array($p)) continue;
            $nom       = isset($p['nom']) ? sanitize_text_field($p['nom']) : '';
            $prenom    = isset($p['prenom']) ? sanitize_text_field($p['prenom']) : '';
            $telephone = isset($p['telephone']) ? sanitize_text_field($p['telephone']) : '';
            if ($nom === '' || $prenom === '' || $telephone === '') continue;
            $out[] = array(
                'nom'            => $nom,
                'prenom'         => $prenom,
                'telephone'      => $telephone,
                'lien'           => isset($p['lien']) ? sanitize_text_field($p['lien']) : '',
                'piece_identite' => !empty($p['piece_identite']) ? 1 : 0,
            );
            if (count($out) >= psc_max_pickup_persons_per_child()) break;
        }
        return $out;
    }

    /* ---------------- Soumission publique ---------------- */

    public static function handle_submit() {
        check_admin_referer('psc_submit_request');

        global $wpdb;
        $back = Psc_Mailer::form_page_url();

        // Champ piège : invisible pour un humain, souvent rempli par les
        // robots. S'il est rempli, on simule un succès sans rien créer.
        if (!empty($_POST['psc_website'])) {
            wp_safe_redirect(add_query_arg('psc_msg', 'request_sent', $back));
            exit;
        }

        $email = isset($_POST['req_email']) ? sanitize_email(wp_unslash($_POST['req_email'])) : '';
        if (!is_email($email)) {
            wp_safe_redirect(add_query_arg('psc_msg', 'bad_email', $back));
            exit;
        }
        $email = strtolower($email);

        // Limitation stricte : ce formulaire est public.
        $ok_ip = psc_rate_limit('req_ip_' . psc_client_ip(), 5, HOUR_IN_SECONDS);
        $ok_mail = psc_rate_limit('req_mail_' . $email, 3, DAY_IN_SECONDS);
        if (!$ok_ip || !$ok_mail) {
            // Réponse identique : ne pas révéler que la limite est atteinte.
            wp_safe_redirect(add_query_arg('psc_msg', 'request_sent', $back));
            exit;
        }

        // Si la famille est déjà enregistrée, on ne crée pas de demande :
        // on lui envoie directement son lien de connexion. Le message
        // affiché reste le même, pour ne rien révéler à un tiers.
        if (Psc_Parents::get_by_email($email)) {
            Psc_Parents::send_login_link($email);
            wp_safe_redirect(add_query_arg('psc_msg', 'request_sent', $back));
            exit;
        }

        // Une demande déjà en cours ne doit pas être dupliquée.
        $t = psc_table('requests');
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $t WHERE email = %s AND status IN ('unverified','pending')", $email
        ));

        $nom       = psc_post('req_nom');
        $prenom    = psc_post('req_prenom');
        $telephone = psc_post('req_telephone');
        $adresse     = psc_post('req_adresse');
        $code_postal = psc_post('req_code_postal');
        $ville       = psc_post('req_ville');
        $message   = isset($_POST['req_message'])
            ? sanitize_textarea_field(wp_unslash($_POST['req_message'])) : '';

        // Coordonnées (étape 1) : le "required" HTML5 empêche déjà de
        // passer à l'étape suivante côté client, mais reste contournable
        // (POST direct) — on revalide donc côté serveur.
        if ($nom === '' || $prenom === '' || $telephone === '' || $adresse === '' || $code_postal === '' || $ville === '') {
            wp_safe_redirect(add_query_arg('psc_msg', 'coordonnees_incomplete', $back));
            exit;
        }

        // Second parent (facultatif) : chaque champ reste indépendamment
        // optionnel — contrairement aux personnes autorisées ci-dessous,
        // aucune règle de "tout ou rien" n'est exigée. Seul un format
        // invalide (e-mail/téléphone), s'il est renseigné, fait échouer la
        // soumission plutôt que d'enregistrer une donnée invalide.
        $second_parent_prenom = psc_post('second_parent_prenom');
        $second_parent_nom    = psc_post('second_parent_nom');

        $second_parent_email = '';
        $second_parent_email_raw = psc_post('second_parent_email');
        if ($second_parent_email_raw !== '') {
            if (!is_email($second_parent_email_raw)) {
                wp_safe_redirect(add_query_arg('psc_msg', 'second_parent_bad_email', $back));
                exit;
            }
            $second_parent_email = strtolower(sanitize_email($second_parent_email_raw));
        }

        $second_parent_telephone = '';
        $second_parent_tel_raw = psc_post('second_parent_telephone');
        if ($second_parent_tel_raw !== '') {
            $second_parent_telephone = psc_valid_phone($second_parent_tel_raw);
            if (!$second_parent_telephone) {
                wp_safe_redirect(add_query_arg('psc_msg', 'second_parent_bad_phone', $back));
                exit;
            }
        }

        // Enfants déclarés. Tous les champs (prénom, nom, classe, naissance,
        // justificatif d'assurance) sont obligatoires pour chaque enfant
        // réellement nommé : contrairement à une ligne entièrement vide
        // (ligne inutilisée, simplement ignorée — cf. le "+ Ajouter un
        // enfant" qui laisse des lignes en trop), un enfant explicitement
        // nommé mais incomplet fait échouer TOUTE la soumission — le
        // disparaître silencieusement de la demande serait trompeur pour le
        // parent qui a rempli sa ligne.
        $children = array();
        $assurance_uploads = array(); // index dans $children => $_FILES entry validé
        for ($i = 0; $i < self::MAX_CHILDREN; $i++) {
            $cn = psc_post('child_nom_' . $i);
            $cp = psc_post('child_prenom_' . $i);
            $cc = psc_post('child_classe_' . $i);
            $cb_raw = psc_post('child_naissance_' . $i);
            $cb = psc_valid_date($cb_raw);
            if ($cn === '' && $cp === '' && $cc === '' && $cb_raw === '') continue;
            if ($cn === '' || $cp === '' || $cc === '' || !$cb) {
                wp_safe_redirect(add_query_arg('psc_msg', 'child_incomplete', $back));
                exit;
            }

            $file = isset($_FILES['child_assurance_' . $i]) ? $_FILES['child_assurance_' . $i] : null;
            $file_check = Psc_Frontend::validate_assurance_file($file);
            if ($file_check !== true) {
                $codes = array('too_large' => 'assurance_too_large', 'invalid_type' => 'assurance_invalid_type');
                wp_safe_redirect(add_query_arg('psc_msg', isset($codes[$file_check]) ? $codes[$file_check] : 'assurance_required', $back));
                exit;
            }

            // Personnes autorisées à récupérer cet enfant : facultatif (une
            // ligne totalement vide est ignorée), mais une ligne où au
            // moins un champ est renseigné doit être complète — même
            // logique que pour un enfant explicitement nommé mais
            // incomplet ci-dessus : la faire disparaître silencieusement
            // serait trompeur pour le parent.
            $pickup_persons = array();
            $max_pickup = psc_max_pickup_persons_per_child();
            for ($j = 0; $j < $max_pickup; $j++) {
                $pp_prenom = psc_post("child_pickup_prenom_{$i}_{$j}");
                $pp_nom    = psc_post("child_pickup_nom_{$i}_{$j}");
                $pp_tel    = psc_post("child_pickup_telephone_{$i}_{$j}");
                $pp_lien   = psc_post("child_pickup_lien_{$i}_{$j}");
                if ($pp_prenom === '' && $pp_nom === '' && $pp_tel === '' && $pp_lien === '') continue;
                if ($pp_prenom === '' || $pp_nom === '' || $pp_tel === '') {
                    wp_safe_redirect(add_query_arg('psc_msg', 'pickup_person_incomplete', $back));
                    exit;
                }
                $pickup_persons[] = array(
                    'prenom'         => mb_substr($pp_prenom, 0, 191),
                    'nom'            => mb_substr($pp_nom, 0, 191),
                    'telephone'      => mb_substr($pp_tel, 0, 40),
                    'lien'           => mb_substr($pp_lien, 0, 100),
                    'piece_identite' => isset($_POST["child_pickup_piece_identite_{$i}_{$j}"]) ? 1 : 0,
                );
            }

            $children[] = array(
                'nom'                  => mb_substr($cn, 0, 190),
                'prenom'               => mb_substr($cp, 0, 190),
                'classe'               => mb_substr($cc, 0, 100),
                'date_naissance'       => $cb ?: '',
                'sans_porc'            => isset($_POST['child_sans_porc_' . $i]) ? 1 : 0,
                'vegan'                => isset($_POST['child_vegan_' . $i]) ? 1 : 0,
                'personnes_autorisees' => $pickup_persons,
            );
            $assurance_uploads[count($children) - 1] = $file;
        }

        if (empty($children)) {
            wp_safe_redirect(add_query_arg('psc_msg', 'need_child', $back));
            exit;
        }

        // Règlement intérieur : acceptation obligatoire pour toute demande.
        if (empty($_POST['reglement_accepted'])) {
            wp_safe_redirect(add_query_arg('psc_msg', 'reglement_required', $back));
            exit;
        }

        // Mode de paiement : si prélèvement, le mandat SEPA et le règlement
        // dédié sont obligatoires eux aussi.
        $payment_mode = (isset($_POST['payment_mode']) && $_POST['payment_mode'] === 'prelevement')
            ? 'prelevement' : 'autre';

        $sepa_reglement_accepted_at = null;
        $sepa_titulaire = $sepa_adresse = $sepa_code_postal = $sepa_ville = '';
        $sepa_iban = $sepa_bic = null;

        if ($payment_mode === 'prelevement') {
            if (empty($_POST['sepa_reglement_accepted'])) {
                wp_safe_redirect(add_query_arg('psc_msg', 'sepa_reglement_required', $back));
                exit;
            }

            $sepa_titulaire   = psc_post('sepa_titulaire');
            $sepa_adresse     = psc_post('sepa_adresse');
            $sepa_code_postal = psc_post('sepa_code_postal');
            $sepa_ville       = psc_post('sepa_ville');
            if ($sepa_titulaire === '') {
                wp_safe_redirect(add_query_arg('psc_msg', 'sepa_missing', $back));
                exit;
            }

            $sepa_iban = psc_valid_iban(psc_post('sepa_iban'));
            if (!$sepa_iban) {
                wp_safe_redirect(add_query_arg('psc_msg', 'bad_iban', $back));
                exit;
            }
            $sepa_bic = psc_valid_bic(psc_post('sepa_bic'));
            if (!$sepa_bic) {
                wp_safe_redirect(add_query_arg('psc_msg', 'bad_bic', $back));
                exit;
            }

            $sepa_reglement_accepted_at = current_time('mysql');
        }

        $token = bin2hex(random_bytes(32));
        $data = array(
            'email'                      => $email,
            'nom'                        => mb_substr($nom, 0, 190),
            'prenom'                     => mb_substr($prenom, 0, 190),
            'telephone'                  => mb_substr($telephone, 0, 40),
            'adresse'                    => mb_substr($adresse, 0, 255),
            'code_postal'                => mb_substr($code_postal, 0, 10),
            'ville'                      => mb_substr($ville, 0, 100),
            'children_json'              => wp_json_encode($children),
            'message'                    => mb_substr($message, 0, 1000),
            'verify_hash'                => psc_hash_token($token),
            'verify_expires'             => gmdate('Y-m-d H:i:s', time() + psc_email_confirmation_ttl()),
            'verified'                   => 0,
            'status'                     => 'unverified',
            'reglement_accepted_at'      => current_time('mysql'),
            'payment_mode'               => $payment_mode,
            'sepa_reglement_accepted_at' => $sepa_reglement_accepted_at,
            'sepa_iban'                  => $sepa_iban,
            'sepa_bic'                   => $sepa_bic,
            'sepa_titulaire'             => mb_substr($sepa_titulaire, 0, 190) ?: null,
            'sepa_adresse'               => mb_substr($sepa_adresse, 0, 255) ?: null,
            'sepa_code_postal'           => mb_substr($sepa_code_postal, 0, 10) ?: null,
            'sepa_ville'                 => mb_substr($sepa_ville, 0, 100) ?: null,
            'second_parent_prenom'       => mb_substr($second_parent_prenom, 0, 190) ?: null,
            'second_parent_nom'          => mb_substr($second_parent_nom, 0, 190) ?: null,
            'second_parent_email'        => $second_parent_email ?: null,
            'second_parent_telephone'    => $second_parent_telephone ?: null,
            'created_at'                 => current_time('mysql'),
        );

        if ($existing) {
            $wpdb->update($t, $data, array('id' => $existing->id));
            $request_id = $existing->id;
        } else {
            $wpdb->insert($t, $data);
            $request_id = (int) $wpdb->insert_id;
        }

        // Les chemins des justificatifs dépendent de $request_id, connu
        // seulement maintenant : on les déplace en zone d'attente puis on
        // recomplète children_json. En cas de resoumission (branche
        // $existing ci-dessus), on purge d'abord l'éventuelle zone
        // d'attente précédente pour éviter des fichiers orphelins si le
        // nombre d'enfants a changé entre les deux soumissions.
        self::delete_pending_assurance_files($request_id);
        $pending_dir = self::pending_assurance_dir($request_id);
        wp_mkdir_p($pending_dir);
        foreach ($assurance_uploads as $children_index => $file) {
            $filetype = wp_check_filetype($file['name'], array(
                'pdf'      => 'application/pdf',
                'jpg|jpeg' => 'image/jpeg',
                'png'      => 'image/png',
            ));
            $target = trailingslashit($pending_dir) . 'child-' . $children_index . '.' . $filetype['ext'];
            if (move_uploaded_file($file['tmp_name'], $target)) {
                $children[$children_index]['assurance_rel_path'] = 'periscolaire/assurances/pending/' . $request_id . '/child-' . $children_index . '.' . $filetype['ext'];
                $children[$children_index]['assurance_original_filename'] = sanitize_file_name($file['name']);
            }
        }
        $wpdb->update($t, array('children_json' => wp_json_encode($children)), array('id' => $request_id));

        // Prélèvement : le mandat SEPA est généré tout de suite (la RUM ne
        // dépend que de l'id de la demande, déjà connu) et joint à l'e-mail
        // de confirmation — jamais persisté sur le serveur, il contient un
        // IBAN en clair. Un échec de génération ne doit jamais bloquer
        // l'inscription : l'e-mail part alors simplement sans pièce jointe.
        $mandate_attachments = array();
        if ($payment_mode === 'prelevement') {
            $tmp = Psc_Sepa_Mandate::build_temp_pdf(psc_sepa_mandate_ref($request_id), array(
                'titulaire'   => $sepa_titulaire,
                'adresse'     => $sepa_adresse,
                'code_postal' => $sepa_code_postal,
                'ville'       => $sepa_ville,
                'iban'        => $sepa_iban,
                'bic'         => $sepa_bic,
            ));
            if ($tmp) $mandate_attachments[] = $tmp;
        }

        $url = add_query_arg(
            array('psc_req' => $request_id, 'psc_vtoken' => $token),
            Psc_Mailer::form_page_url()
        );
        Psc_Mailer::send_request_verification($email, $url, $mandate_attachments);

        foreach ($mandate_attachments as $f) { @unlink($f); }

        wp_safe_redirect(add_query_arg('psc_msg', 'request_sent', $back));
        exit;
    }

    /* ---------------- Vérification de l'adresse ---------------- */

    public static function maybe_verify() {
        if (empty($_GET['psc_vtoken']) || empty($_GET['psc_req'])) return;

        global $wpdb;

        $id = absint($_GET['psc_req']);
        $token = sanitize_text_field(wp_unslash($_GET['psc_vtoken']));
        $redirect = remove_query_arg(array('psc_vtoken', 'psc_req'));

        $req = self::get($id);

        if (!$req || $req->status !== 'unverified' || empty($req->verify_hash)) {
            wp_safe_redirect(add_query_arg('psc_msg', 'bad_verify', $redirect));
            exit;
        }
        if (strtotime($req->verify_expires . ' UTC') < time()) {
            wp_safe_redirect(add_query_arg('psc_msg', 'expired_verify', $redirect));
            exit;
        }
        if (!hash_equals($req->verify_hash, psc_hash_token($token))) {
            wp_safe_redirect(add_query_arg('psc_msg', 'bad_verify', $redirect));
            exit;
        }

        $wpdb->update(
            psc_table('requests'),
            array(
                'verified'       => 1,
                'status'         => 'pending',
                'verify_hash'    => null,
                'verify_expires' => null,
            ),
            array('id' => $req->id),
            array('%d', '%s', '%s', '%s'),
            array('%d')
        );

        // Validation automatique (Réglages) : la famille accède directement
        // à son espace, sans relecture par la mairie — mêmes écritures que
        // handle_approve(), déclenchées ici au lieu d'un clic mairie. On est
        // déjà dans le navigateur du parent (c'est lui qui vient de cliquer
        // le lien de confirmation) : on ouvre donc sa session tout de suite
        // et on le redirige directement dans son espace connecté, plutôt
        // que de lui faire attendre un second e-mail avec un lien d'accès
        // qu'il devrait encore aller chercher. Le mail "compte activé" est
        // donc inutile ici (send_login_email=false) : la session vient
        // d'être ouverte via le lien qu'il vient de prouver, pas besoin
        // d'un second lien d'accès dans sa boîte mail. Un échec (aucun
        // enfant valide, essentiellement) retombe simplement sur le
        // parcours normal : la demande reste "pending" pour la mairie,
        // rien n'est perdu.
        if (psc_auto_approve_requests_enabled()) {
            $req = self::get($req->id);
            $children = self::children_of($req);
            if (!empty($children)) {
                $result = self::approve_request($req, $children, false);
                if (!is_wp_error($result)) {
                    Psc_Parents::open_session($result);
                    wp_safe_redirect(add_query_arg('psc_msg', 'welcome', $redirect));
                    exit;
                }
            }
        }

        Psc_Mailer::notify_mairie_new_request($req, self::children_of($req));

        wp_safe_redirect(add_query_arg('psc_msg', 'verified', $redirect));
        exit;
    }

    /* ---------------- Modération (backoffice) ---------------- */

    public static function handle_approve() {
        if (!psc_user_can_manage()) {
            wp_die(esc_html__('Accès refusé.', 'periscolaire-registration'), '', array('response' => 403));
        }
        check_admin_referer('psc_approve_request');

        $req = self::get(psc_post_int('id'));
        if (!$req || $req->status !== 'pending') {
            Psc_Admin::redirect_public('psc_requests', 'invalid');
        }

        // La mairie peut avoir corrigé les noms/classes avant validation.
        // Le justificatif d'assurance, lui, n'est jamais éditable depuis ce
        // formulaire : toujours re-dérivé de children_json par index
        // d'origine, jamais d'un champ POST (évite qu'un chemin de fichier
        // arbitraire puisse être soumis).
        $req_children = self::children_of($req);
        $children = array();
        for ($i = 0; $i < self::MAX_CHILDREN; $i++) {
            $cn = psc_post('child_nom_' . $i);
            $cp = psc_post('child_prenom_' . $i);
            $cc = psc_post('child_classe_' . $i);
            $cb = psc_valid_date(psc_post('child_naissance_' . $i));
            if ($cn === '' || $cp === '') continue;
            $children[] = array(
                'nom'                          => mb_substr($cn, 0, 190),
                'prenom'                       => mb_substr($cp, 0, 190),
                'classe'                       => mb_substr($cc, 0, 100),
                'date_naissance'               => $cb ?: '',
                'sans_porc'                    => isset($_POST['child_sans_porc_' . $i]) ? 1 : 0,
                'vegan'                        => isset($_POST['child_vegan_' . $i]) ? 1 : 0,
                'assurance_rel_path'           => $req_children[$i]['assurance_rel_path'] ?? '',
                'assurance_original_filename'  => $req_children[$i]['assurance_original_filename'] ?? '',
                // Comme le justificatif d'assurance : jamais re-lu depuis un
                // champ POST (ce formulaire n'en propose pas l'édition),
                // toujours re-dérivé de la demande d'origine par index.
                'personnes_autorisees'         => $req_children[$i]['personnes_autorisees'] ?? array(),
            );
        }
        if (empty($children)) {
            $children = $req_children;
        }
        if (empty($children)) {
            Psc_Admin::redirect_public('psc_requests', 'need_child');
        }

        $result = self::approve_request($req, $children);
        if (is_wp_error($result)) {
            Psc_Admin::redirect_public('psc_requests', 'invalid');
        }

        Psc_Admin::redirect_public('psc_requests', 'approved');
    }

    /**
     * Cœur de l'approbation d'une demande : crée ou retrouve la famille,
     * crée les enfants, les inscrit dans l'année active, matérialise les
     * personnes autorisées déclarées, rattache le justificatif d'assurance
     * en attente, clôt la demande, envoie le lien d'accès. Partagé par
     * handle_approve() (validation manuelle par la mairie) et
     * maybe_verify() (validation automatique, cf. Réglages > Demandes
     * d'inscription) — aucun des deux appelants ne doit dupliquer cette
     * logique. $children est déjà résolu par l'appelant (édité par la
     * mairie ou tel quel depuis children_of($req)) : cette méthode ne lit
     * jamais $_POST elle-même. Renvoie l'id du parent créé/retrouvé, ou
     * WP_Error.
     *
     * $send_login_email : à false quand l'appelant vient d'ouvrir la
     * session du parent lui-même dans la même requête (validation
     * automatique juste après confirmation d'adresse) — un e-mail "compte
     * activé" serait alors garanti inutile, le parent étant déjà connecté.
     * Toujours true pour une validation manuelle par la mairie : c'est
     * alors la seule façon pour le parent de recevoir son accès.
     */
    protected static function approve_request($req, $children, $send_login_email = true) {
        global $wpdb;

        // Règlement, mode de paiement et mandat SEPA déclarés dans la
        // demande : reportés tels quels sur le compte famille créé.
        $parent_extra = array(
            'adresse'                    => $req->adresse ?? '',
            'code_postal'                => $req->code_postal ?? '',
            'ville'                      => $req->ville ?? '',
            'payment_mode'               => $req->payment_mode ?? 'autre',
            'sepa_iban'                  => $req->sepa_iban ?? null,
            'sepa_bic'                   => $req->sepa_bic ?? null,
            'sepa_titulaire'             => $req->sepa_titulaire ?? null,
            'sepa_adresse'               => $req->sepa_adresse ?? null,
            'sepa_code_postal'           => $req->sepa_code_postal ?? null,
            'sepa_ville'                 => $req->sepa_ville ?? null,
            'reglement_accepted_at'      => $req->reglement_accepted_at ?? null,
            'sepa_reglement_accepted_at' => $req->sepa_reglement_accepted_at ?? null,
            'second_parent_prenom'       => $req->second_parent_prenom ?? null,
            'second_parent_nom'          => $req->second_parent_nom ?? null,
            'second_parent_email'        => $req->second_parent_email ?? null,
            'second_parent_telephone'    => $req->second_parent_telephone ?? null,
        );
        if (($req->payment_mode ?? 'autre') === 'prelevement') {
            $parent_extra['sepa_mandate_ref'] = psc_sepa_mandate_ref($req->id);
        }

        // Création de la famille (ou récupération si elle existe déjà).
        $parent = Psc_Parents::get_by_email($req->email);
        if ($parent) {
            $parent_id = (int) $parent->id;
            Psc_Parents::update($parent_id, $parent_extra);
        } else {
            $parent_id = Psc_Parents::create($req->email, $req->nom, array_merge($parent_extra, array('prenom' => $req->prenom ?? '')));
            if (is_wp_error($parent_id)) {
                return $parent_id;
            }
        }

        $active_year_id = Psc_School_Years::active_id();

        foreach ($children as $c) {
            $wpdb->insert(psc_table('children'), array(
                'parent_id'      => $parent_id,
                'nom'            => $c['nom'],
                'prenom'         => $c['prenom'],
                'date_naissance' => !empty($c['date_naissance']) ? $c['date_naissance'] : null,
                'sans_porc'      => !empty($c['sans_porc']) ? 1 : 0,
                'vegan'          => !empty($c['vegan']) ? 1 : 0,
                'statut'         => 'actif',
                'created_at'     => current_time('mysql'),
            ), array('%d', '%s', '%s', '%s', '%d', '%d', '%s', '%s'));
            $child_id = (int) $wpdb->insert_id;

            if ($active_year_id) {
                Psc_School_Years::enroll($child_id, $active_year_id, $c['classe'], 'inscrit', $req->reglement_accepted_at ?? current_time('mysql'));
            }

            // Personnes autorisées déclarées à l'onboarding : l'auteur réel
            // de l'information est la famille (source='parent'), même si
            // c'est ce code (déclenché par un clic mairie ou par la
            // validation automatique) qui effectue l'écriture — aucune
            // session parent n'existe à ce moment-là.
            if (!empty($c['personnes_autorisees']) && is_array($c['personnes_autorisees'])) {
                foreach ($c['personnes_autorisees'] as $p) {
                    Psc_Pickup_Persons::add($child_id, $p, 'parent', $parent_id);
                }
            }

            // Rattache le justificatif déposé en zone d'attente au nouvel
            // enfant. Pas de blocage dur si le fichier est introuvable
            // (cas limite) : la demande doit toujours pouvoir être
            // approuvée, l'enfant reste rattrapable via « Mes enfants ».
            if (!empty($c['assurance_rel_path'])) {
                $abs = trailingslashit(wp_upload_dir()['basedir']) . $c['assurance_rel_path'];
                if (file_exists($abs)) {
                    Psc_Frontend::promote_pending_assurance($child_id, $abs, $c['assurance_original_filename'] ?? '');
                }
            }
        }

        self::delete_pending_assurance_files($req->id);

        $wpdb->update(
            psc_table('requests'),
            array('status' => 'approved', 'decided_at' => current_time('mysql')),
            array('id' => $req->id),
            array('%s', '%s'),
            array('%d')
        );

        // Le parent reçoit directement son lien d'accès — sauf s'il est
        // déjà connecté (validation automatique, cf. maybe_verify()).
        if ($send_login_email) {
            Psc_Parents::send_login_link($req->email, 'approved');
        }

        return $parent_id;
    }

    public static function handle_reject() {
        if (!psc_user_can_manage()) {
            wp_die(esc_html__('Accès refusé.', 'periscolaire-registration'), '', array('response' => 403));
        }
        check_admin_referer('psc_reject_request');

        global $wpdb;
        $req = self::get(psc_post_int('id'));
        if (!$req || $req->status !== 'pending') {
            Psc_Admin::redirect_public('psc_requests', 'invalid');
        }

        $note = isset($_POST['note']) ? sanitize_textarea_field(wp_unslash($_POST['note'])) : '';
        $notify = !empty($_POST['notify']);

        $wpdb->update(
            psc_table('requests'),
            array(
                'status'     => 'rejected',
                'note'       => mb_substr($note, 0, 1000),
                'decided_at' => current_time('mysql'),
            ),
            array('id' => $req->id),
            array('%s', '%s', '%s'),
            array('%d')
        );

        if ($notify) {
            Psc_Mailer::send_request_rejected($req->email, $note);
        }

        Psc_Admin::redirect_public('psc_requests', 'rejected');
    }

    public static function handle_delete() {
        if (!psc_user_can_manage()) {
            wp_die(esc_html__('Accès refusé.', 'periscolaire-registration'), '', array('response' => 403));
        }
        check_admin_referer('psc_delete_request');

        global $wpdb;
        $id = psc_post_int('id');
        if ($id) {
            self::delete_pending_assurance_files($id);
            $wpdb->delete(psc_table('requests'), array('id' => $id), array('%d'));
        }
        Psc_Admin::redirect_public('psc_requests', 'deleted');
    }
}
